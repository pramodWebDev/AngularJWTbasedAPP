import { NgModule } from "@angular/core";

import { CommonModule } from "@angular/common";

import { dashboardComponent } from "../components/dashboard.component";

import { AboutModule } from "../../about/modules/about.module";

import { HomeModule } from "../../home/modules/home.module";

import { PortfolioModule } from "../../portfolio/modules/portfolio.module";

import { Routes,RouterModule } from "@angular/router";

export const appRoutes:Routes = [
    {path:"",component:dashboardComponent,
     children:[
        {path:"about",loadChildren:"../../about/modules/about.module#AboutModule"},
               
        {path:"home",loadChildren:"../../home/modules/home.module#HomeModule"},
               
        {path:"portfolio",loadChildren:"../../portfolio/modules/portfolio.module#PortfolioModule"}
     ]
    }
];
@NgModule({
    declarations:[dashboardComponent],
    imports:[CommonModule,
             RouterModule.forChild(appRoutes)],
    providers:[],
    exports:[dashboardComponent]
})
export class DashboardModule{}
