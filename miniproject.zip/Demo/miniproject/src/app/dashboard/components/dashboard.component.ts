import { Component } from "@angular/core";
import { Router } from "@angular/router";
@Component({
    selector:"dashboard",
    templateUrl:"./dashboard.component.html"
})
export class dashboardComponent{
    constructor(private router:Router){}
    public logout():any{
        window.localStorage.removeItem("login_details");
        this.router.navigate(["/"]);
    };
};