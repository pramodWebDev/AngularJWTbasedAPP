import { BrowserModule } from '@angular/platform-browser';

import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { LoginModule } from "./login/modules/login.module";

import { DashboardModule } from "./dashboard/modules/dashboard.module";

import { Routes,RouterModule } from "@angular/router";

export const appRoutes:Routes = [
  {path:"",loadChildren:"./login/modules/login.module#LoginModule"},
  
  {path:"dashboard",loadChildren:"./dashboard/modules/dashboard.module#DashboardModule"}
];


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }