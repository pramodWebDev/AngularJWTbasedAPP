import { Injectable } from "@angular/core";

import { tokenService } from '../services/token.service';

import { HttpRequest, 
         HttpHandler, 
         HttpEvent } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable({
    providedIn:"root"
})
export class authInterceptor{
    constructor(private service:tokenService){}
    
    intercept(req:HttpRequest<any>,
              handler:HttpHandler)
                :Observable<HttpEvent<any>>{
        
        if(req.url=="http://localhost:8080/authenticate")
        {
            return handler.handle(req);
        }else{
            const req1 = req.clone({
                setHeaders:{
                    "Authorization":"Bearer "+this.service.getToken()
                }
            });
            return handler.handle(req1);
        }
    }
};