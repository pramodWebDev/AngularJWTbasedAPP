import { Injectable } from "@angular/core";
@Injectable({
    providedIn:"root"
})
export class tokenService{
    public getToken():string{
        let str = window.localStorage.getItem("login_details");

        let obj = JSON.parse(str);

        let token = obj.jwt;
        
        return token;
    };
};