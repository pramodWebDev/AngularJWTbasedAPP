import { NgModule } from "@angular/core";

import { CommonModule } from '@angular/common';

import { tokenService } from '../services/token.service';

import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';

import { authInterceptor } from '../interceptor/auth.interceptor';

@NgModule({
    declarations:[],
    imports:[CommonModule],
    providers:[tokenService,
               HttpClientModule,
                {
                    provide:HTTP_INTERCEPTORS,
                    useClass:authInterceptor,
                    multi:true
                }
               ],
    exports:[]
})
export class TokenModule{}