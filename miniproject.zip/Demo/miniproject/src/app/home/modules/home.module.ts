import { NgModule } from "@angular/core";

import { homeComponent } from '../components/home.component';

import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

import { TokenModule } from 'src/app/token/module/token.module';

import { RouterModule } from '@angular/router';

import { homeService } from '../services/home.service';
@NgModule({
    declarations:[homeComponent],
    imports:[CommonModule,
             HttpClientModule,
             TokenModule,
             RouterModule.forChild([{
                 path:"",component:homeComponent
             }])],
    providers:[homeService],
    exports:[homeComponent]    
})
export class HomeModule{}