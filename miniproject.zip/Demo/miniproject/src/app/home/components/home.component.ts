import { Component } from "@angular/core";
import { homeService } from '../services/home.service';
import errCallBack from 'src/app/error/errCallBack';
@Component({
    selector:"home",
    templateUrl:"./home.component.html"
})
export class homeComponent{
    private result:any;
    constructor(private service:homeService){}
    ngOnInit(){
        this.service.getHomeModuleData()
                                .subscribe((posRes)=>{
            this.result = posRes;
        },errCallBack);
    };
};