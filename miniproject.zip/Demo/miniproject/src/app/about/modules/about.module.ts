import { NgModule } from "@angular/core";

import { aboutComponent } from '../components/about.component';

import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

import { TokenModule } from 'src/app/token/module/token.module';

import { aboutService } from '../services/about.service';

import { Routes,RouterModule } from "@angular/router";

export const appRoutes:Routes = [
    {path:"",component:aboutComponent}
];
@NgModule({
    declarations:[aboutComponent],
    imports:[CommonModule,
            HttpClientModule,
            TokenModule,
            RouterModule.forChild(appRoutes)],
    providers:[aboutService],
    exports:[aboutComponent]
})
export class AboutModule{}