let SPRING_BOOT:any = {
    BASE_URL : "http://localhost:8080"
};
export default SPRING_BOOT;