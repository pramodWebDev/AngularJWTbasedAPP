import { Component } from "@angular/core";
import { portfolioService } from '../services/portfolio.service';
import errCallBack from 'src/app/error/errCallBack';
@Component({
    selector:"portfolio",
    templateUrl:"./portfolio.component.html"
})
export class portfolioComponent{
    private result:any;
    constructor(private service:portfolioService){}
    ngOnInit(){
        this.service.getPortfolioModuleData()
                                .subscribe((posRes)=>{
            this.result = posRes;
        },errCallBack);
    };
};