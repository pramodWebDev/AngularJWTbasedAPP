import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import SPRING_BOOT from 'src/app/urls/url';
@Injectable({
    providedIn:"root"
})
export class portfolioService{
    constructor(private http:HttpClient){}
    public getPortfolioModuleData():Observable<any>{
        return this.http.get(SPRING_BOOT.BASE_URL+"/portfolio");
    };
};