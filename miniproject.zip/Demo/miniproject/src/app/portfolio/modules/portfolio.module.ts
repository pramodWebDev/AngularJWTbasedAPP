import { NgModule } from "@angular/core";

import { portfolioComponent } from '../components/portfolio.component';

import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

import { TokenModule } from 'src/app/token/module/token.module';

import { RouterModule } from '@angular/router';

import { portfolioService } from '../services/portfolio.service';
@NgModule({
    declarations:[portfolioComponent],
    imports:[CommonModule,
             HttpClientModule,
             TokenModule,
             RouterModule.forChild([{
                 path:"",
                 component:portfolioComponent
             }])],
    providers:[portfolioService],
    exports:[portfolioComponent]    
})
export class PortfolioModule{}