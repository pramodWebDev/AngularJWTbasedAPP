import { Component } from "@angular/core";
import { loginService } from "../services/login.service";
import errCallBack from "../../error/errCallBack"; 
import { Router } from "@angular/router";
//where Router class used to navigate from One Component to another Component in single page application

@Component({
    selector:"login",
    templateUrl:"./login.component.html"
})
export class loginComponent{
    constructor(private service:loginService,
                private router:Router){}
    
    public login(obj:any):any{
        //when ever we click the login button automatically login() function will be executed.
        //argument is obj.
        //where obj is the JSON Object.
        //obj containes @username @password
        this.service.authenticate(obj)
                    .subscribe((posRes)=>{
            //check the login status
            if(posRes.login == "success"){
                //convert posRes to string format
                let str = JSON.stringify(posRes);
                //store the str to localStorage
                window.localStorage.setItem("login_details",str);
                //navigate to Dashborad
                this.router.navigate(["/dashboard"]);
            }else{
                alert("Login Fail");
            }
        },errCallBack);
    };
};








