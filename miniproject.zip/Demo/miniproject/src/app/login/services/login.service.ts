import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import SPRING_BOOT from "../../urls/url";
@Injectable({
    providedIn:"root"
})
export class loginService{
    constructor(private http:HttpClient){}
    public authenticate(obj:any):Observable<any>{
        //where obj is the argument.
        //where obj is the JSON Object.
        //obj containes  @username  @password
        //obj coming from loginComponent
        //we will send obj to server.
        return this.http.post(SPRING_BOOT.BASE_URL+"/authenticate",obj);
    };
};