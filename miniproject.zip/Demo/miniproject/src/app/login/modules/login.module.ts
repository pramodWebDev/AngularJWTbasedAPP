//import NgModule
//NgModule used to create the Custom Modules
import { NgModule } from "@angular/core";

//import loginComponent
import { loginComponent } from "../components/login.component";

//import loginService
import { loginService } from "../services/login.service";

//import HttpClientModule
//loginService makes the rest api call
import { HttpClientModule } from "@angular/common/http";


//import FormsModule
//we are using [(ngModel)] in loginComponent
import { FormsModule } from "@angular/forms";

//import CommonModule
//CommonModule used to recognize the child modules
import { CommonModule } from "@angular/common";


//import Routes and RouterModule
//these classes used to make the loginComponent as default component in LoginModule
import { Routes,RouterModule } from "@angular/router";
//make the loginComponent as default component in LoginModule
export const appRoutes:Routes = [
    {path:"",component:loginComponent}
];
@NgModule({
    declarations:[loginComponent],
    imports:[CommonModule,
             HttpClientModule,
             FormsModule,
             RouterModule.forChild(appRoutes)],
    providers:[loginService],
    exports:[loginComponent]
})
export class LoginModule{}
